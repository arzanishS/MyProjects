// Name : Arzanish Sarwar
// ID : R00170508

import java.text.DecimalFormat;
import java.util.ArrayList;

public class RobotMoving {
	double right ; //for right value
	double down ; //for left value
	double diagonal ; //for diagonal value
	double matrix [][];
	private String path [][];
	private ArrayList<String> movement ; // tracking the movement of robot for reaching point
	double cost = 0; // cost for each cell in matrix
	
	public RobotMoving(int n,double right ,double down, double diagonal) {
	    
		this.right =right ;
		this.down =down;
		this.diagonal =diagonal ;
		matrix=new double [n][n];
		this.path = new String [n][n];
		movement = new ArrayList<String>();
		
		
		
	}

public void robo(int n) {
		//calculating prices for each cell in matric
		matrix[0][0] = 0.0;
		path [0][0] = "  - ";
		for (int j = 1; j < n; j ++) {
			matrix[0][j] = matrix[0][j-1] + right;
			path [0][j] = "right";
		}
		for (int i = 1; i < n; i ++) {
			matrix [i][0] = matrix[i-1][0] + down;
			path [i][0] = "down ";
			for(int j= 1; j < n; j++) {
				//calculating minimum cost for reaching the cell
				matrix [i][j] = min(matrix[i][j-1] + right,
						matrix[i-1][j] + down,
						matrix[i-1][j-1] + diagonal, i, j);
				
			}
		}
		//storing cost for each cell;
		cost = matrix[n-1][n-1];
		
	}
public double min(double r, double d, double dia, int i, int j) {
		double res = 0;
		if (r < d && r < dia) {
			path[i][j] = "right";
			res = r;
		}
		else if (d < r && d < dia) {
			path[i][j] = "down ";
			res = d;
		}
		else { 
			path[i][j] = "diag ";
			res = dia;
		}
		return res;
		}
		
	
	
public void print () {
	DecimalFormat Df = new DecimalFormat("0.0");	
		//printing the calculated paths and prices for matrix
		for (int row = 0; row < matrix.length; row ++) {
			for (int col = 0; col < matrix.length; col ++) {
				System.out.print(Df.format(matrix[row][col]) + " ");
			}
			System.out.println();
		}
		System.out.println("\nTotal Path: ");
		for (int row = 0; row < path.length; row ++) {
			for (int col = 0; col < path.length; col ++) {
				System.out.print(path[row][col] + " ");
			}
			System.out.println();
		}
	}

public void path () {
	//back tracking the path and storing the best path
	int i = matrix.length - 1;
	int j = matrix.length - 1;
	
	System.out.println("\nThe total cost from point:"+ i +", " + j +
			" to point: 0, 0 is �" + matrix[i][j]);
	
	while (i != -1 && j != -1) {
		if (path [i][j] == "right") {
			
			System.out.println("We reached point: (" + i +", " + j + ") from point: (" 
					+ i +", "+ (j+1) 
					+ "). With a cost of �" + right);
			
			movement.add("right");
			j--;
		}
		else if (path [i][j] == "down ") {
			
			System.out.println("We reached point: (" + i +", " + j + ") from point: (" 
					+ (i+1) +", "+ j 
					+ "). With a cost of �" + down);
			movement.add("down");
			i--;
		}
		else if (path [i][j] == "diag ") {
			
			System.out.println("We reached point: (" + i +", " + j + ") from point: (" 
					+ (i+1) +", "+ (j+1) 
					+ "). With a cost of �" + diagonal);
		    
			movement.add("diagonal");
			i--;
			j--;
		}
		else {
			i--;
			j--;
		}
	}
	
	
}
	
  public void movement() {
	 //printing the best path among all paths 
	int lastpoint = matrix.length;
	System.out.println("\nBest Path for to Move from 0,0 to "+lastpoint+","+lastpoint+"\n");
	
	for (int i = movement.size()-1;i>=0; i--) {
		if(movement.get(i) != "") {
			System.out.print(movement.get(i)+",");
		}
	}
	System.out.println();
  }
	
	public static void main(String[] args) {
		//cost1 
		System.out.println("\n---------------\nFor cost 1 :\n---------------");
		RobotMoving rm1=new RobotMoving (10,1.1,1.3,2.5);
		rm1.robo(10);
		rm1.print();
		rm1.path();
		rm1.movement();
		//cost2
		System.out.println("\n---------------\nFor cost 2 :\n---------------");
		RobotMoving rm2=new RobotMoving (10,1.5,1.2,2.3);
		rm2.robo(10);
		rm2.print();
		rm2.path();
		rm2.movement();
	

	}

}
