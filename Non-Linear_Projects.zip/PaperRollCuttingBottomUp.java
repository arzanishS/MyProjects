// Name : Arzanish Sarwar
// ID : R00170508
import java.util.ArrayList;

public class PaperRollCuttingBottomUp {
	
	
	private ArrayList<Double> cutPrices; // it will hold the price for each cut
	private ArrayList<ArrayList<Integer>> cutLengths; // it will hold sub cuts for each cut
	private ArrayList<Double> optimalPrices; // stores the best price for each cut
	private int cutAti =0, cutAtj =0; 
	private int rodLength =0;
	public PaperRollCuttingBottomUp() {
		cutPrices = new ArrayList<Double>();
		cutLengths = new ArrayList<ArrayList<Integer>>();
		optimalPrices = new ArrayList<Double>();
		
		cutLengths.add(0, new ArrayList<Integer>());
		
		cutPrices.add(0.0);
		cutPrices.add(1.2);
		cutPrices.add(3.0);
		cutPrices.add(5.8);
		cutPrices.add(0.0);
		cutPrices.add(10.1);
		
		optimalPrices.add(0.0);
		
	}
	
	public double rodCut(int n) {
		this.rodLength = n;
		
		
	
		if(n<=0) {
			System.out.println("Length Should be valid !!");
		   return 0;
		}
		
		else {
			double q =0.0;
			for(int i =1 ;i<=n ;i++) {
				
				double bestPrice = 0.0;
				
				if(i>5) {
					cutPrices.add(i,0.0);
				}
				
				for(int j =1;j<=i;j++) {
					//calculating best price and comparing with previous prices
					bestPrice = Math.max(bestPrice,cutPrices.get(j)+optimalPrices.get(i-j)); 
					
					if(bestPrice>q) {
						//storing best price
						q = bestPrice;
						cutAti =i-j;
						cutAtj =j;
					}
				}
				//storing cuts for best price  
				cutLengths.add(i,new ArrayList<Integer>());
                cutLengths.get(i).add(cutAtj);				
				
				if(cutAti !=0) {
					cutLengths.get(i).add(cutAti);
					
				}	
	     		optimalPrices.add(i,q);
	     		
				
	     		
			}
			
			
		}	
		return optimalPrices.get(n);
	}
	
	
	public void print() {
 
		System.out.println("Length of Rod provided : "+this.rodLength+" Has total revenue : � "+optimalPrices.get(this.rodLength));
		System.out.println("\n-------prices-------- \n");
		for(int i=1; i<=this.rodLength ;i++) {
			System.out.println("length cut :"+i+" price : � "+optimalPrices.get(i));
		}
		
		System.out.println("\n-------cuts for each length-------- \n");
		
			for(int i =1;i<optimalPrices.size();i++) {
				System.out.print("cuts are for length : "+i+" = ");
				for(int j=0;  j < cutLengths.get(i).size() ;j++) { 	
					if(cutLengths.get(i).get(j) <=5) {
						System.out.print(cutLengths.get(i).get(j) +",");
					}
					else {
						int x = cutLengths.get(i).get(j);
						for (int j1 = 0; j1 < cutLengths.get(x).size() ;j1++) {
							System.out.print(cutLengths.get(x).get(j1)+",");
						}
					}
				}
	          System.out.println();
			}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PaperRollCuttingBottomUp p1 = new PaperRollCuttingBottomUp();
		int length = 7;
 		p1.rodCut(length);
		p1.print();	
		
	}
}
