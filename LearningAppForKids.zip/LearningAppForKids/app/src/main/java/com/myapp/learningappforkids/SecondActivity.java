package com.myapp.learningappforkids;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.Serializable;
public class SecondActivity extends AppCompatActivity  {

    private Wild_Animal_class animal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Intent i = getIntent();
        this.animal = (Wild_Animal_class) i.getSerializableExtra("Object");
        bgImage();
        funFact();
        wikipedia();
        sound();
    }

    public void bgImage(){
        LinearLayout ll = (LinearLayout) findViewById(R.id.linear);
        ll.setBackgroundResource(animal.getBgImage());
    }

    public void funFact(){
        TextView text = (TextView) findViewById(R.id.funFact);
        text.setText(this.animal.getFunfact());
    }

    public void wikipedia(){
        Button bt = (Button) findViewById(R.id.wikipedia);
        Uri web = Uri.parse(getResources().getString(animal.getWikipedia()));
        final Intent it = new Intent(Intent.ACTION_VIEW,web);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                startActivity(it);
            }
        });
    }

    public void sound(){
        Button sound = (Button) findViewById(R.id.sound);
        final MediaPlayer music = MediaPlayer.create(this, animal.getSound());

        sound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                music.start();
            }
        });
    }

}