package com.myapp.learningappforkids;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MyRecyclerViewAdapter.ItemClickListener {

    MyRecyclerViewAdapter adapter;
    private ArrayList<Wild_Animal_class> list = new ArrayList<Wild_Animal_class>();
    private ArrayList<String> animalNames = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // data to populate the RecyclerView with
        list.add(new Wild_Animal_class("Zebra",R.drawable.img1,R.string.animal1,R.drawable.bgimg1,R.string.link1,R.raw.sound1));
        list.add(new Wild_Animal_class("Cheetah",R.drawable.img2_48px,R.string.animal2,R.drawable.bgimg2,R.string.link2,R.raw.sound2));
        list.add(new Wild_Animal_class("Deer",R.drawable.img3,R.string.animal3,R.drawable.bgimg3,R.string.link3,R.raw.sound3));
        list.add(new Wild_Animal_class("Tiger",R.drawable.img4,R.string.animal4,R.drawable.bgimg4,R.string.link4,R.raw.sound4));
        list.add(new Wild_Animal_class("Kangaroo",R.drawable.img5,R.string.animal5,R.drawable.bgimg5,R.string.link5,R.raw.sound5));
        list.add(new Wild_Animal_class("Wolf",R.drawable.img6,R.string.animal6,R.drawable.bgimg6,R.string.link6,R.raw.sound6));
        list.add(new Wild_Animal_class("Gorilla",R.drawable.img7,R.string.animal7,R.drawable.bgimg7,R.string.link7,R.raw.sound7));
        list.add(new Wild_Animal_class("Giraffe",R.drawable.img8,R.string.animal8,R.drawable.bgimg8,R.string.link8,R.raw.sound8));
        list.add(new Wild_Animal_class("Fox",R.drawable.img9,R.string.animal9,R.drawable.bgimg9,R.string.link9,R.raw.sound9));
        list.add(new Wild_Animal_class("Panda",R.drawable.img10,R.string.animal10,R.drawable.bgimg10,R.string.link10,R.raw.sound10));
        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvAnimals);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, list);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);

    }

    @Override
    public void onItemClick(View view, int position) {
        Toast.makeText(this, "You clicked " + adapter.getItem(position).getAnimalName() , Toast.LENGTH_SHORT).show();
        Intent send = new Intent(this,SecondActivity.class);
        send.putExtra("Object", adapter.getItem(position));
        startActivity(send);
    }


}