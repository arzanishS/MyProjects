package com.myapp.learningappforkids;

import java.io.Serializable;


public class Wild_Animal_class implements Serializable {

    private  String animalName;
    private int imageURL;
    private int funfact ;
    private int bgImage;
    private int wikipedia;
    private int sound;
    public Wild_Animal_class(String name , int imageURL,int funFact,int bgImage,int wikipedia,int sound){

        this.animalName = name;
        this.imageURL = imageURL;
        this.funfact = funFact;
        this.bgImage = bgImage;
        this.wikipedia = wikipedia;
        this.sound = sound;
    }

    public String getAnimalName() {
        return animalName;
    }

    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public int getImageURL() {
        return imageURL;
    }

    public void setImageURL(int imageURL) {
        this.imageURL = imageURL;
    }

    public int getFunfact() {
        return funfact;
    }

    public void setFunfact(int funfact) {
        this.funfact = funfact;
    }

    public int getBgImage() {
        return bgImage;
    }

    public void setBgImage(int bgImage) {
        this.bgImage = bgImage;
    }

    public int getWikipedia() {
        return wikipedia;
    }

    public void setWikipedia(int wikipedia) {
        this.wikipedia = wikipedia;
    }

    public int getSound() {
        return sound;
    }

    public void setSound(int sound) {
        this.sound = sound;
    }
}
